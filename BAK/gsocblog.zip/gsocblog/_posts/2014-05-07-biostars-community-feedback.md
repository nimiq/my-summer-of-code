---
layout: post
title: "Biostars Community Feedback"
description: "Feedback from Biostar Community"
link: https://www.biostars.org/p/99956/
modified: 2014-05-07 23:12:23 +0200
category: 
tags: [feedback, usability, biostar, community]
image:
  feature: 
  credit: 
  creditlink: 
comments: true
share: true
---

A page to collect feedback about [Biostars](https://www.biostars.org).
