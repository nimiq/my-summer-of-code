---
layout: post
title: "My GSoC Proposal"
description: "The original submitted proposal."
link: https://docs.google.com/document/d/1yBkXf29MP_Hjc7G7Ayd30iL6z7-1aLA53j7ezLQuPXk/edit?usp=sharing
modified: 2014-05-05 11:14:40 +0200
tags: [proposal, neurostars, gsoc, idea]
comments: true
share: true
---

This is the original proposal I submitted to GSoC for **NeuroStars**.

This is not exactly the plan of the activities that we will be doing, but only a rough idea of what we could do.

A more detailed plan will be made in the coming months together with my mentors *Roman* and *Satrajit* and checked with *Istvan*. We will also ask the [bioinformatics community](https://groups.google.com/forum/#!forum/biostar-central) for feedback.